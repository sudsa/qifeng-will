package com.qifeng.will.handle;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandleApplicationTests {

	@Test
	void contextLoads() {
	}

}
