package com.qifeng.will.listener;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListenerApplicationTests {

	@Test
	void contextLoads() {
	}

}
