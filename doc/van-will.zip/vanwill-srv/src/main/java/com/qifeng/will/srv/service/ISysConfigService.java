package com.qifeng.will.srv.service;

import com.baomidou.mybatisplus.service.IService;
import com.qifeng.will.base.warrior.entity.SysConfig;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zhw
 * @since 2021-07-22
 */
public interface ISysConfigService extends IService<SysConfig> {
	
}
