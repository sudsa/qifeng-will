package com.qifeng.will.srv.feign;

import org.springframework.cloud.openfeign.FeignClient;

//@FeignClient
public class UserClientFeign {


}
