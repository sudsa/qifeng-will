package com.qifeng.will.srv;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SrvApplicationTests {

	@Test
	public void contextLoads() {
	}

}
