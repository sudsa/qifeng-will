package com.qifeng.will.base.dto;

import lombok.Data;

@Data
public class OperateDetail {

    private String operateKey;

    private String operateVal;

    private String keyName;

}
