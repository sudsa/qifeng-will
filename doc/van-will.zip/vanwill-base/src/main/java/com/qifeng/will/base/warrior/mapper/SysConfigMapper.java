package com.qifeng.will.base.warrior.mapper;

import com.qifeng.will.base.warrior.entity.SysConfig;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author zhw
 * @since 2021-07-22
 */
public interface SysConfigMapper extends BaseMapper<SysConfig> {

}